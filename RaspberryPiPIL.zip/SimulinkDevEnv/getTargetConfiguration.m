function tc = getTargetConfiguration()
% Copyright 2015 The MathWorks, Inc

tc.IP = '192.168.1.151';
tc.PortStr = '17725';
tc.login = 'pi';
tc.password = 'raspberry';
tc.folder = '/home/pi/workarea';

% Add compiler info here
tc.compilerInstallDir = 'C:\SysGCC\Raspberry\bin';
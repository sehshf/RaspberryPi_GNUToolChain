function sl_customization(cm)
% SL_CUSTOMIZATION for raspberryPiPIL
%  - Specifies the valid configuration parameter settings to enable the
%    raspberryPiPIL implementation.

% Copyright 2015 The MathWorks, Inc

cm.registerTargetInfo(@loc_createConfig);

% Get default (factory) customizations
hObj = cm.RTWBuildCustomizer;


% Specify settings for valid PIL configuration
function config = loc_createConfig

config = rtw.connectivity.ConfigRegistry;
config.ConfigName  = 'Raspberry Pi PIL';
config.ConfigClass = 'raspberryPiPIL.ConnectivityConfig';

% The following model configuration settings must be matched to be valid
config.SystemTargetFile   = {'ert.tlc'};
config.Toolchain   = {'raspberryPiw64 | gmake makefile (64-bit Windows)'};
config.TargetHWDeviceType = {};

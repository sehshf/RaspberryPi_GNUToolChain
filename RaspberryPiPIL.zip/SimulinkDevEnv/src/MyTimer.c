#include "MyTimer.h"
#include <time.h>

uint16_T MyTimer()
{
struct timespec gettime_now;

clock_gettime(CLOCK_REALTIME, &gettime_now);
return (uint16_T)gettime_now.tv_nsec;	
}

function rtwTargetInfo(tr)
%RTWTARGETINFO Registration file for custom toolchains.

% Copyright 2015 The MathWorks, Inc

tr.registerTargetInfo(@loc_createToolchain);

end

% -------------------------------------------------------------------------
% Create the ToolchainInfoRegistry entries
% -------------------------------------------------------------------------
function config = loc_createToolchain

config(1)                       = coder.make.ToolchainInfoRegistry;
config(1).Name                  = 'raspberryPiw64 | gmake makefile (64-bit Windows)';
config(1).FileName              = fullfile(fileparts(mfilename('fullpath')), 'raspberryPiw64_tc.mat');
config(1).TargetHWDeviceType    = {'*'};
config(1).Platform              =  {computer('arch')};

end

% Updates the stored file 
% Copyright 2015 The MathWorks, Inc

thispath = fileparts(mfilename('fullpath'));
tc = raspberryPiw64_tc();
save(fullfile(thispath,'raspberryPiw64_tc.mat'), 'tc');
clear tc

% rehash the targets 
RTW.TargetRegistry.getInstance('reset');
function tc = raspberryPiw64_tc
%RASPBERRYPIW64_TC Creates an Raspberry Pi ToolchainInfo object.

% Copyright 2015 The MathWorks, Inc

% Some environment requires the use of "rm" instead of "del" when deleting
% files/folders. This can be changed by setting the variable
% useRmInsteadOfDel to true
useRmInsteadOfDel = false;

targetConfig = getTargetConfiguration;

tc = coder.make.ToolchainInfo('BuildArtifact', 'gmake makefile');
tc.Name             = 'RaspberryPi | gmake makefile (64-bit Windows)';
tc.Platform         = 'win64';
tc.SupportedVersion = '4.6';

tc.addAttribute('TransformPathsWithSpaces');
tc.addAttribute('RequiresCommandFile');
tc.addAttribute('RequiresBatchFile');

% ------------------------------
% Setup
% ------------------------------

tc.ShellSetup{1} = ['set PATH=%PATH%;' targetConfig.compilerInstallDir];

% ------------------------------
% Macros
% ------------------------------
tc.addMacro('MW_EXTERNLIB_DIR',     ['$(MATLAB_ROOT)\extern\lib\' tc.Platform '\microsoft']);
tc.addMacro('MW_LIB_DIR',           ['$(MATLAB_ROOT)\lib\' tc.Platform]);
tc.addMacro('CFLAGS_ADDITIONAL',    '');
tc.addMacro('CPPFLAGS_ADDITIONAL',  '');
tc.addMacro('LIBS_TOOLCHAIN',       '');
tc.addMacro('CVARSFLAG',            '');

tc.addIntrinsicMacros({'ANSI_OPTS', 'CPP_ANSI_OPTS'});


% ------------------------------
% C Compiler
% ------------------------------
 
tool = tc.getBuildTool('C Compiler');

tool.setName(           'RaspberryPi C Compiler');
tool.setCommand(        'arm-linux-gnueabihf-gcc');
tool.setPath(           '');

tool.setDirective(      'IncludeSearchPath',    '-I');
tool.setDirective(      'PreprocessorDefine',   '-D');
tool.setDirective(      'OutputFlag',           '-o');
tool.setDirective(      'Debug',                '-g');

tool.setFileExtension(  'Source',               '.c');
tool.setFileExtension(  'Header',               '.h');
tool.setFileExtension(  'Object',               '.obj');

tool.Libraries = {'-lrt'};

tool.setCommandPattern('|>TOOL<| |>TOOL_OPTIONS<| |>OUTPUT_FLAG<||>OUTPUT<|');

% ------------------------------
% C++ Compiler
% ------------------------------

tool = tc.getBuildTool('C++ Compiler');

tool.setName(           'RaspberryPi C++ Compiler');
tool.setCommand(        'arm-linux-gnueabihf-g++');
tool.setPath(           '');

tool.setDirective(      'IncludeSearchPath',  	'-I');
tool.setDirective(      'PreprocessorDefine', 	'-D');
tool.setDirective(      'OutputFlag',           '-o');
tool.setDirective(      'Debug',                '-g');

tool.setFileExtension(  'Source',               '.cpp');
tool.setFileExtension(  'Header',               '.hpp');
tool.setFileExtension(  'Object',               '.obj');

tool.setCommandPattern('|>TOOL<| |>TOOL_OPTIONS<| |>OUTPUT_FLAG<||>OUTPUT<|');

% ------------------------------
% Linker
% ------------------------------

tool = tc.getBuildTool('Linker');

tool.setName(           'RaspberryPi C/C++ Linker');
tool.setCommand(        'arm-linux-gnueabihf-gcc');
tool.setPath(           '');

tool.setDirective(      'Library',              '-l');
tool.setDirective(      'LibrarySearchPath',    '-L');
tool.setDirective(      'OutputFlag',           '-o');
tool.setDirective(      'Debug',                '-g');

tool.setFileExtension(  'Executable',           '');
tool.setFileExtension(  'Shared Library',       '.a');

tool.setCommandPattern('|>TOOL<| |>TOOL_OPTIONS<| |>OUTPUT_FLAG<||>OUTPUT<|');

% ------------------------------
% C++ Linker
% ------------------------------

tool = tc.getBuildTool('C++ Linker');

tool.setName(           'RaspberryPi C/C++ Linker');
tool.setCommand(        'arm-linux-gnueabihf-g++');
tool.setPath(           '');

tool.setDirective(      'Library',              '-l');
tool.setDirective(      'LibrarySearchPath',    '-L');
tool.setDirective(      'OutputFlag',           '-o');
tool.setDirective(      'Debug',                '-g');

tool.setFileExtension(  'Executable',           '');
tool.setFileExtension(  'Shared Library',       '.a');

tool.setCommandPattern('|>TOOL<| |>TOOL_OPTIONS<| |>OUTPUT_FLAG<||>OUTPUT<|');

% ------------------------------
% Archiver
% ------------------------------

tool = tc.getBuildTool('Archiver');

tool.setName(           'RaspberryPi C/C++ Archiver');
tool.setCommand(        'arm-linux-gnueabihf-ar');
tool.setPath(           '');
tool.setDirective(      'OutputFlag',           '');
tool.setFileExtension(  'Static Library',       '.a');
tool.setCommandPattern('|>TOOL<| |>TOOL_OPTIONS<| |>OUTPUT_FLAG<||>OUTPUT<|');

% ------------------------------
% Builder
% ------------------------------

tc.setBuilderApplication(tc.Platform);

if useRmInsteadOfDel
    tool = tc.BuilderApplication;
    tool.setDirective('DeleteCommand', '@rm');
end


% --------------------------------------------
% BUILD CONFIGURATIONS
% --------------------------------------------

% ----------------------------------
% Compiler optimization levels
% ----------------------------------

% optimsOff is obtained from GCC manual (i.e. man gcc) on glnxa64 and maci
optimsOffOpts = {'-O0'};
% optimsOn is obtained from mexopts file: <matlabroot>/bin/mexopts.sh
optimsOnOpts = {'-O3 -fno-loop-optimize'};

profileOpts.compiler = {'-fprofile-arcs' '-ftest-coverage' '-pg'};
profileOpts.linker   = {'-fprofile-arcs' '-ftest-coverage' '-pg'};
profileOpts.archiver = {};

% ----------------------------------
% Baseline options
% ----------------------------------

cCompilerOpts    = {'-c $(ANSI_OPTS)'};
cppCompilerOpts  = {'-c $(CPP_ANSI_OPTS)'};
linkerOpts       = {'-Wl,-rpath,"$(MATLAB_ARCH_BIN)",-L"$(MATLAB_ARCH_BIN)"'};
sharedLinkerOpts = {'-shared -Wl,-rpath,"$(MATLAB_ARCH_BIN)",-L"$(MATLAB_ARCH_BIN)" -Wl,--no-undefined'};
archiverOpts     = {'ruvs'};


% Get the debug flag per build tool
debugFlag.CCompiler   = '$(CDEBUG)';   
debugFlag.CppCompiler = '$(CPPDEBUG)';
debugFlag.Linker      = '$(LDDEBUG)';  
debugFlag.CppLinker   = '$(CPPLDDEBUG)';  
debugFlag.Archiver    = '$(ARDEBUG)';  

% Set the toolchain flags for 'Faster Builds' build configuration

cfg = tc.getBuildConfiguration('Faster Builds');
cfg.setOption( 'C Compiler',                horzcat(cCompilerOpts,   optimsOffOpts));
cfg.setOption( 'C++ Compiler',              horzcat(cppCompilerOpts, optimsOffOpts));
cfg.setOption( 'Linker',                    linkerOpts);
cfg.setOption( 'C++ Linker',                linkerOpts);
cfg.setOption( 'Shared Library Linker',     sharedLinkerOpts);
cfg.setOption( 'Archiver',                  archiverOpts);

% Set the toolchain flags for 'Faster Runs' build configuration

cfg = tc.getBuildConfiguration('Faster Runs');
cfg.setOption( 'C Compiler',                horzcat(cCompilerOpts,   optimsOnOpts));
cfg.setOption( 'C++ Compiler',              horzcat(cppCompilerOpts, optimsOnOpts));
cfg.setOption( 'Linker',                    linkerOpts);
cfg.setOption( 'C++ Linker',                linkerOpts);
cfg.setOption( 'Shared Library Linker',     sharedLinkerOpts);
cfg.setOption( 'Archiver',                  archiverOpts);

% Set the toolchain flags for 'Debug' build configuration

cfg = tc.getBuildConfiguration('Debug');
cfg.setOption( 'C Compiler',              	horzcat(cCompilerOpts,   optimsOffOpts, debugFlag.CCompiler));
cfg.setOption( 'C++ Compiler',          	horzcat(cppCompilerOpts, optimsOffOpts, debugFlag.CppCompiler));
cfg.setOption( 'Linker',                	horzcat(linkerOpts,       debugFlag.Linker));
cfg.setOption( 'C++ Linker',               	horzcat(linkerOpts,       debugFlag.CppLinker));
cfg.setOption( 'Shared Library Linker',  	horzcat(sharedLinkerOpts, debugFlag.Linker));
cfg.setOption( 'Archiver',              	horzcat(archiverOpts,     debugFlag.Archiver));

% add a "profile and coverage" build configuration
tc.addBuildConfiguration('Profile&Coverage');
cfg = tc.getBuildConfiguration('Profile&Coverage');
cfg.setOption( 'C Compiler',              	horzcat(cCompilerOpts,   optimsOffOpts, profileOpts.compiler));
cfg.setOption( 'C++ Compiler',          	horzcat(cppCompilerOpts, optimsOffOpts, profileOpts.compiler));
cfg.setOption( 'Linker',                	horzcat(linkerOpts,       profileOpts.linker));
cfg.setOption( 'C++ Linker',               	horzcat(linkerOpts,       profileOpts.linker));
cfg.setOption( 'Shared Library Linker',  	horzcat(sharedLinkerOpts, profileOpts.linker));
cfg.setOption( 'Archiver',              	horzcat(archiverOpts, profileOpts.archiver));

tc.setBuildConfigurationOption('all', 'Download',      '');
tc.setBuildConfigurationOption('all', 'Execute',       '');
tc.setBuildConfigurationOption('all', 'Make Tool',     '-f $(MAKEFILE)');

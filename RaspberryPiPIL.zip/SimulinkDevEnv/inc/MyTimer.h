#include "rtwTypes.h"

uint16_T MyTimer();

classdef ConnectivityConfig < rtw.connectivity.Config
% Copyright 2015 The MathWorks, Inc

    methods
        function this = ConnectivityConfig(componentArgs)
            
            % 1. Set up target communication
            targetApplicationFramework = ...
                raspberryPiPIL.TargetApplicationFramework(componentArgs);
            
            % 2. Instantiate the builder
            builder = raspberryPiPIL.MakefileBuilder(componentArgs, ...
                targetApplicationFramework);
            
            % 3. Instantiate the launcher
            launcher = raspberryPiPIL.Launcher(componentArgs, builder);
            
            % 4. Set up host communication
                % File extension for shared libraries (e.g. .dll on Windows)
                sharedLibExt=system_dependent('GetSharedLibExt'); 
                % Evaluate name of the rtIOStream shared library
                rtiostreamLib = ['libmwrtiostreamtcpip' sharedLibExt];
                hostCommunicator = rtw.connectivity.RtIOStreamHostCommunicator(...
                    componentArgs, ...
                    launcher, ...
                    rtiostreamLib);
                % Set a timeout value for initial setup of the communications
                % channel
                hostCommunicator.setInitCommsTimeout(20); 
                % Configure a timeout period for reading of data by the host 
                % from the target.
                timeoutReadDataSecs = 60;
                hostCommunicator.setTimeoutRecvSecs(timeoutReadDataSecs);
                % Custom arguments that will be passed to the              
                % rtIOStreamOpen function in the rtIOStream shared        
                % library (this configures the host-side of the           
                % communications channel)  
                tc = getTargetConfiguration();
                rtIOStreamOpenArgs = {...                                  
                    '-hostname', tc.IP, ...                         
                    '-client', '1', ...                                    
                    '-blocking', '1', ...                                  
                    '-port', tc.PortStr,...                                 
                    };                           
                hostCommunicator.setOpenRtIOStreamArgList(...          
                    rtIOStreamOpenArgs); 
                
            % 5. Call super class constructor to register components
            this@rtw.connectivity.Config(componentArgs,...
                                         builder,...
                                         launcher,...
                                         hostCommunicator);
            
            % 6. Register hardware specific timer
            this.setTimer(raspberryPiPIL.RaspberryPiPILCRL());
        end
    end
end


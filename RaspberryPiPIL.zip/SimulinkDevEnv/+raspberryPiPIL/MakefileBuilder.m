classdef MakefileBuilder < rtw.connectivity.MakefileBuilder
% Copyright 2015 The MathWorks, Inc

    methods
        
         function this = MakefileBuilder(componentArgs, ...
                                        targetApplicationFramework)
            narginchk(2, 2);
            % call super class constructor                             
            this@rtw.connectivity.MakefileBuilder(componentArgs, ...
                                targetApplicationFramework, '');
         end      
    end

end

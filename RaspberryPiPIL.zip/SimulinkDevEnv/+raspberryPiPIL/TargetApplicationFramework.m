classdef TargetApplicationFramework < rtw.pil.RtIOStreamApplicationFramework
% Copyright 2015 The MathWorks, Inc

    methods
        function this = TargetApplicationFramework(componentArgs)
            narginchk(1, 1);
            % call super class constructor
            this@rtw.pil.RtIOStreamApplicationFramework(componentArgs);
            
            % To build the PIL application you must specify a main.c file.                                  
            this.addPILMain('target');                                             
            
            % Additional source and library files to include in the build        
            % must be added to the BuildInfo property                                      
            % Get the BuildInfo object to update                                 
            buildInfo = this.getBuildInfo;                                       
            
            % Add device driver files to implement the target-side of the        
            % host-target rtIOStream communications channel                      
            rtiostreamPath = fullfile(matlabroot, ...                            
                                      'rtw', ...                                 
                                      'c', ...                                   
                                      'src', ...                                 
                                      'rtiostream', ...                          
                                      'rtiostreamtcpip');
            buildInfo.addSourcePaths(rtiostreamPath);                            
            buildInfo.addSourceFiles('rtiostream_tcpip.c');
            
            incPath = fullfile(matlabroot, ...                            
                                      'rtw', ...                                 
                                      'c', ...                                   
                                      'src');   
            buildInfo.addIncludePaths(incPath);
        end
    end
end

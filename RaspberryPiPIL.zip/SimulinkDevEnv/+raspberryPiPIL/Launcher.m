classdef Launcher < rtw.connectivity.Launcher
% Copyright 2015 The MathWorks, Inc

    properties
        ProcessName = '';
    end

    methods
        % constructor
        function this = Launcher(componentArgs, builder)
            narginchk(2, 2);
            % call super class constructor
            this@rtw.connectivity.Launcher(componentArgs, builder);
        end
        
        % destructor
        function delete(this) %#ok
            
            % This method is called when an instance of this class is cleared from memory,
            % e.g. when the associated Simulink model is closed. You can use
            % this destructor method to close down any processes, e.g. an IDE or
            % debugger that was originally started by this class. If the
            % stopApplication method already performs this housekeeping at the
            % end of each on-target simulation run then it is not necessary to
            % insert any code in this destructor method. However, if the IDE or
            % debugger may be left open between successive on-target simulation
            % runs then it is recommended to insert code here to terminate that
            % application.

        end                                                 
               
        % Start the application
        function startApplication(this)
            % get name of the executable file
            exe = this.getBuilder.getApplicationExecutable;

            disp('### Downloading PIL application...')
            
            tc = getTargetConfiguration();
            [~, filename, ~] = fileparts(exe);
            this.ProcessName = filename;
            
            run_filename = 'run_pil.sh';
            fid = fopen(run_filename, 'w');
            fprintf(fid, ['./', filename, ' -port ', tc.PortStr, ' &']);
            fclose(fid);

            st = system(['winscp /command "option batch abort" "option confirm off" "open sftp://', ...
                         tc.login, ':', tc.password, '@', tc.IP, '/" "cd ', tc.folder, ...
                         '" "put ', exe, '" "put ', run_filename, '" "call chmod +x ', filename, ...
                         '" "call bash ', run_filename, '" "close" "exit"']);
            if st ~= 0
                disp('### ERROR downloading PIL application!');
            else
                disp('### Application started');
            end           

        end
        
        % Stop the application
        function stopApplication(this)
            
            disp('### Stopping application...');         
            
            tc = getTargetConfiguration();
                     
            st = system(['winscp /command "option batch abort" "option confirm off" "open sftp://', ...
                         tc.login, ':', tc.password, '@', tc.IP, '/" "cd ', tc.folder, ...
                         '" "call killall ', this.ProcessName, '" "close" "exit"']);
                     
            if st ~= 0
                disp('### ERROR stopping application!');
            end
            disp('### Application stopped');
        end
    end
end

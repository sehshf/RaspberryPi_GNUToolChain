% Startup file for the Rapsberry Pi
% Copyright 2015 The MathWorks, Inc

% Add path to Development Environment
addpath([pwd, filesep, 'SimulinkDevEnv'], '-end');
addpath([pwd, filesep, 'SimulinkDevEnv', filesep, 'raspberryPi_tc_setup'], '-end');

% Add path to examples
addpath([pwd, filesep, 'Examples'], '-end');

% Go to workarea
cd workarea